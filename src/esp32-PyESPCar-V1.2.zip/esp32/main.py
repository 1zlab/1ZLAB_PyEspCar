'''
程序入口
'''
from machine import Pin
import utime

if __name__ == '__main__':
    # MQTT小车控制模式
    # mqtt会影响WebREPL的连接，默认不运行
    exec(open('mqtt_control_mode.py').read(), globals())
    # print('ESP32 Run Nothing')